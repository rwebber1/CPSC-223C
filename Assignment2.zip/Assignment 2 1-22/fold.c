/*
 * Author:		Riley Webber
 * Class:		CPSC 223
 * Date:		2/5/2020
 * Topic(s):	Folding
 */

#include <stdlib.h>
#include <stdio.h>
#include "files.h"

#define FOLD_LENGTH 60          //Characters per line

int main(int argc, const char* argv[]){
	FILE* fin;
	FILE* fout;

	// open input and output files
	if (!open_io_files(argc, argv, &fin, &fout, 3, 4,"Usage: ./fold.c inputfile outputfile\n")) {
		exit(1);
	}

	// process input file to remove spaces and substitute tabs
	int c, counter;

	while ((c = fgetc(fin)) != EOF) {
		fputc(c, fout);
		counter++;

		if(counter >= FOLD_LENGTH && c == ' '){
			fputc('\n',fout);
			counter = 0;
		}
	}

	closefiles(2, fin, fout);  // must say number of files

	return 0;
}
