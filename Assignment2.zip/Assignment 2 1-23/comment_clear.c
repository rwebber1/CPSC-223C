/*
 * Author:		Riley Webber
 * Class:		CPSC 223
 * Date:		2/5/2020
 * Topic(s):	Comment Clearing
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "files.h"

//Program to scan through text file of code and remove comments
//Passing arguments test.txt output.txt through command line
int main(int argc, const char* argv[]){
	FILE* fin;
	FILE* fout;

	// open input and output files
	if (!open_io_files(argc, argv, &fin, &fout, 3, 4,                   "Usage: ./comment_clear.c inputfile outputfile")) {
		exit(1);
	}

	// process input file to remove comments
	int c, d, e, f;
	while ((c = fgetc(fin)) != EOF) {
		//Adds characters to output file unless it may be comment
		if (c != '/') {
			fputc(c, fout);
		}
		//confirm if it is single line comment
		else if((d = fgetc(fin)) == '/'){
			while((e=fgetc(fin))!=EOF)
			{
				if(e =='\n'){ break;}
			}
		}
		//confirm if it is a block comment
		else if(d == '*'){
			while((e=fgetc(fin))!=EOF)
			{
				if(e =='*')
				{
					f = fgetc(fin);
					if(f == '/'){ break;}
				}
			}
		}
		//was not a comment, put into output file
		else{
			fputc(c,fout);
			fputc(d,fout);
		}
	}

	closefiles(2, fin, fout);  // must say number of files
	return 0;
}


