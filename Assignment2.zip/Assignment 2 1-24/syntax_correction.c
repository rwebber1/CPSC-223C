/*
 * Author:		Riley Webber
 * Class:		CPSC 223
 * Date:		2/5/2020
 * Topic(s):	Syntax checking
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "files.h"

//Program to scan through text file of code and check for unbalanced syntax
//Passing argument test.txt through command line
int main(int argc, const char* argv[]){
	FILE* fin;

	// open input and output files
	if (!open_io_files(argc, argv, &fin, 2, 3,"Usage: ./comment_clear.c inputfile")) {
		exit(1);
	}

	// process input file to remove comments
	int c, parenthesis, bracket, brace, quote, double_quote;

	while ((c = fgetc(fin)) != EOF) {
		if(c == '('){
			parenthesis++;
		}
		else if(c == ')'){
			parenthesis--;
		}
		else if(c == '['){
			bracket++;
		}
		else if(c == ']'){
			bracket--;
		}
		else if(c == '{'){
			bracket++;
		}
		else if(c == '}'){
			brace--;
		}
		else if(c == '"'){
			double_quote++;
		}
		else if(c == '"'){
			double_quote--;
		}
		else if(c == '\''){
			quote++;
		}
		else if(c == '\''){
			quote--;
		}
	}

	if(parenthesis != 0)
	{
		printf("Parenthensis are unbalanced!\n");
	}
	if(bracket != 0)
	{
		printf("Brackets are unbalanced!\n");
	}
	if(brace != 0)
	{
		printf("Braces are unbalanced!\n");
	}
	if(double_quote != 0)
	{
		printf("Double quotes are unbalanced!\n");
	}
	if(quote != 0)
	{
		printf("Quotes are unbalanced!\n");
	}

	closefiles(1, fin);  // must say number of files
	return 0;
}
